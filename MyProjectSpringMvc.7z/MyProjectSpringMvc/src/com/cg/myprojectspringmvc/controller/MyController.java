package com.cg.myprojectspringmvc.controller;

import java.math.BigInteger;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.myprojectspringmvc.dto.Address;
import com.cg.myprojectspringmvc.dto.Course;
import com.cg.myprojectspringmvc.dto.Student;
import com.cg.myprojectspringmvc.exception.CourseNotFoundException;
import com.cg.myprojectspringmvc.service.CourseService;

/**@author siontedd:Written by Sirisha on 15-04-2019
*Last modified on 22-05-2019
*The class MyController is used to control the whole application by using the @controller 
*annotation.we will also redirect to the mentioned jsp pages
 */


@Controller
public class MyController {
	@Autowired
	CourseService service;
	Course cou;
	
	@GetMapping("login")
	public String loginPage() {
		//System.out.println("hi...........");
		return "listPage";
		
	}
	
	@GetMapping("addpage")
	public ModelAndView getAdd(@ModelAttribute("course") Course courseOne) {
		return new ModelAndView("addCourse");
		}
	@PostMapping("addcourse")
	public ModelAndView addCourse(@ModelAttribute("course") Course courseOne) {
		Course courseTwo = null;
		try {
			System.out.println(courseOne);
			courseTwo = service.add(courseOne);
		} catch (CourseNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("success","key",courseTwo);
		
	}
	@GetMapping("showpage")
	public ModelAndView getShowAll() {
		List<Course> myAllCourses = null;
		try {
			myAllCourses = service.showAllCourses();
		} catch (CourseNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("showCourse","keyOne",myAllCourses);
	}
	@GetMapping("searchpage")
	public ModelAndView getSearch() {
		return new ModelAndView("search");
		
	}
	@PostMapping("searchCourse")
	public ModelAndView getSearchOne(@RequestParam("sub") String name) {
		try {
			List<Course> couList=service.showAllCourses();
			for (Course course2 : couList) {
				if(course2.getSubject().equals(name)) {
					
					return new ModelAndView("listStudents","keyOne",course2.getStudents());
				}
				
		} 
			throw new CourseNotFoundException("course not found");
		}catch (CourseNotFoundException e) {
			// TODO Auto-generated catch block
			//System.out.println("hi.........siri");
			return new ModelAndView("errorpage");
		}
		//return null;
		//return null;
		
		
	}
	@GetMapping("registerpage")
	public ModelAndView getRegister() {
		
		return new ModelAndView("searchOne");
		
	}
	@PostMapping("retrievepage")
	public ModelAndView postRegister(
			@RequestParam("stuname") String name,@RequestParam("stuNo") BigInteger phoneNo,
			@RequestParam("stuEmail") String email,
			@RequestParam("city") String city,@RequestParam("state") String state,
			@RequestParam("pincode") Integer pincode,@RequestParam("stu") String course) throws SQLException {
		Course courseTwo = null;
		try {
			List<Course> couList=service.showAllCourses();
			for (Course course2 : couList) {
				if(course2.getSubject().equals(course)) {
			System.out.println("hii...Controller..");
			
			Student stu=new Student();
			Address add=new Address();
			Course cour=new Course();
			cour.setId(course2.getId());
			cour.setSubject(course2.getSubject());
			
			
			stu.setName(name);
			stu.setPhoneNumber(phoneNo);
			stu.setEmailAddress(email);
			add.setCity(city);
			add.setState(state);
			add.setPinCode(pincode);
			stu.setAddress(add);
			stu.setCourse(cour);
			System.out.println(cour+" "+stu);
			courseTwo = service.registerForCourse(course,stu);
			return new ModelAndView("retrieve","keyOne",courseTwo);
			}
			}
			throw new CourseNotFoundException("course not found");
		} catch (CourseNotFoundException e) {
			// TODO Auto-generated catch block
			return new ModelAndView("errorpage");
		}/* catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
	}
}
