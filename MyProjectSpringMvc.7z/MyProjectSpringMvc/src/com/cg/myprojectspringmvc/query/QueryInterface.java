package com.cg.myprojectspringmvc.query;
/**Written by Sirisha on 15-04-2019
Last modified on 03-05-2019
The Method QueryInterface is used to write the jpql queries*/

public interface QueryInterface {
	String sql="from Course where subject =:subject";
	String qStr = "SELECT course FROM Course course ";
}
