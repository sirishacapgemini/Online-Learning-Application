package com.cg.myprojectspringmvc.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**@author siontedd:Written by Sirisha on 15-04-2019
*Last modified on 22-05-2019
*The class AppContexts is used to write the Jpa configuration by using the @configuration 
@PropertySource,@ComponentScan,@EnableTransactionManagement
 */
	@Configuration
	@PropertySource("classpath:resources/mysql.properties")
	@ComponentScan("com.cg.myprojectspringmvc")
	@EnableTransactionManagement
	public class AppContexts {
		@Autowired
		Environment environment;

		@Bean
		public LocalSessionFactoryBean sessionFactory() {
			LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
			sessionFactory.setDataSource(dataSource());
			sessionFactory.setPackagesToScan(new String[] { "com.cg.myprojectspringmvc.dto" });
			sessionFactory.setHibernateProperties(hibernateProperties());
			return sessionFactory;
		}
		@Bean
		public DataSource dataSource() {
			DriverManagerDataSource dataSource = new DriverManagerDataSource();
			dataSource.setDriverClassName(environment.getRequiredProperty("mysql.driver"));
			dataSource.setUrl(environment.getRequiredProperty("mysql.url"));
			dataSource.setUsername(environment.getRequiredProperty("mysql.userName"));
			dataSource.setPassword(environment.getRequiredProperty("mysql.password"));
			return dataSource;
		}
		private Properties hibernateProperties() {
			Properties properties = new Properties();
			properties.put("hibernate.dialect", environment.getRequiredProperty("mysql.dialect"));
			properties.put("hibernate.hbm2ddl.auto", environment.getRequiredProperty("mysql.auto"));
		    properties.put("hibernate.format_sql", true);
			return properties;
		}
		@Bean
		public HibernateTransactionManager getTransactionManager() {
			HibernateTransactionManager transactionManager = new HibernateTransactionManager();
			transactionManager.setSessionFactory(sessionFactory().getObject());
			return transactionManager;
		}
		
}
