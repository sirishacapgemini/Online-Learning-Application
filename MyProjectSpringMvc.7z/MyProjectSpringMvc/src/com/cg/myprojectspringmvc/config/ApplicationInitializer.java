package com.cg.myprojectspringmvc.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

/**@author siontedd:Written by Sirisha on 15-04-2019
*Last modified on 22-05-2019
*The class ApplicationInitializer extends AbstractAnnotationConfigDispatcherServletInitializer 
 is to register a DispatcherServlet and use Java-based Spring configuration. 
*/

public class ApplicationInitializer extends AbstractAnnotationConfigDispatcherServletInitializer{

@Override
protected Class<?>[] getRootConfigClasses() {
	// TODO Auto-generated method stub
	return new Class[] {AppContexts.class};
}

@Override
protected Class<?>[] getServletConfigClasses() {
	// TODO Auto-generated method stub
	return new Class [] {WebMvc.class};
}

@Override
protected String[] getServletMappings() {
	// TODO Auto-generated method stub
	return new String [] {"/"};
}
}
