package com.cg.myprojectspringmvc.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name="course_table")
public class Course {
@Id
@Column(name="course_id")
private Integer id;
@Column(name="course_subject")
private String subject;
@OneToMany(cascade=CascadeType.ALL,mappedBy="course",fetch=FetchType.EAGER)
private List<Student> students;
	public Course() {
	}
	
	public Course(Integer id, String subject, List<Student> students) {
		super();
		this.id = id;
		this.subject = subject;
		this.students = students;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	@Override
	public String toString() {
		return "Course [id=" + id + ", subject=" + subject + ", students=" + students + "]";
	}
	
}
