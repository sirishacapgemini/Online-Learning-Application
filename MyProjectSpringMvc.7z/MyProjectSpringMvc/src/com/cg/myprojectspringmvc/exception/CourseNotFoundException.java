package com.cg.myprojectspringmvc.exception;
/**@author siontedd:Written by Sirisha on 15-04-2019
*Last modified on 22-05-2019
*The class CourseNotFoundException extends Exception which is used to throw the exception
 */
public class CourseNotFoundException extends Exception{
	public CourseNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CourseNotFoundException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}
}
