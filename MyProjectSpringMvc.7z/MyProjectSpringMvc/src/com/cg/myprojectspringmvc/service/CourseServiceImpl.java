package com.cg.myprojectspringmvc.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.myprojectspringmvc.dao.CourseRepository;
import com.cg.myprojectspringmvc.dto.Course;
import com.cg.myprojectspringmvc.dto.Student;
import com.cg.myprojectspringmvc.exception.CourseNotFoundException;

@Service
@Transactional
public class CourseServiceImpl implements CourseService{
	@Autowired
	private CourseRepository repository;
	
	/**@author siontedd:Written by Sirisha on 15-04-2019
	 Last modified on 22-05-2019
	 The Method registerForCourse() is used to add new student to the particular mentioned subject*/
	public Course registerForCourse(String subject, Student student) throws CourseNotFoundException, SQLException{
		// TODO Auto-generated method stub
		List<Student> stu=new ArrayList<>();
		stu.add(student);
		Course course=new Course();
		course.setId(student.getCourse().getId());
		course.setSubject(student.getCourse().getSubject());
		course.setStudents(stu);
		
		 repository.save(course);
		//throw new CourseNotFoundException("course not found");
		return course;

	}
	/**@author siontedd:Written by Sirisha on 15-04-2019
	 Last modified on 22-05-2019
	 The Method add() is used to add new course into the database*/
public Course add(Course course) throws CourseNotFoundException, SQLException {
		// TODO Auto-generated method stub
		repository.save(course);
		return course;
		}
/**@author siontedd:Written by Sirisha on 15-04-2019
Last modified on 22-05-2019
The Method searchBySubject() is used to search a particular subject and returns the list of students who got registered for that course*/
public List<Student> searchBySubject(String subject) throws CourseNotFoundException{
	Course course=repository.findBySubject(subject);
	if(course==null)
		throw new CourseNotFoundException("course not found");
	    	return course.getStudents();
}
/**@author siontedd:Written by Sirisha on 15-04-2019
Last modified on 22-05-2019
The Method showAllCourses() is used to retrieve all the courses which are there in the database*/
	public List<Course> showAllCourses() throws CourseNotFoundException {
		// TODO Auto-generated method stub
				List<Course> list=repository.showAllCourses();
				if(list==null)
					throw new CourseNotFoundException("course not found");
				return list;
		}
@Override
public Course searchByName(String course) throws CourseNotFoundException {
	// TODO Auto-generated method stub
	return repository.findBySubject(course);
}
}
