package com.cg.myprojectspringmvc.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.myprojectspringmvc.dto.Course;
import com.cg.myprojectspringmvc.dto.Student;
import com.cg.myprojectspringmvc.exception.CourseNotFoundException;



public interface CourseService {
	public Course registerForCourse(String subject,Student students) throws CourseNotFoundException, SQLException;
	public Course add(Course course) throws CourseNotFoundException, SQLException, CourseNotFoundException;
	public List<Student> searchBySubject(String subject) throws CourseNotFoundException;
	public Course searchByName(String course) throws CourseNotFoundException;
	public List<Course> showAllCourses() throws CourseNotFoundException;
}
