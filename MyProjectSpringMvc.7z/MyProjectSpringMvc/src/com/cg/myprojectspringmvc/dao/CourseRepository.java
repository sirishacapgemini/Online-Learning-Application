package com.cg.myprojectspringmvc.dao;

import java.util.List;

import com.cg.myprojectspringmvc.dto.Course;
import com.cg.myprojectspringmvc.dto.Student;
import com.cg.myprojectspringmvc.exception.CourseNotFoundException;


public interface CourseRepository {
	public Course save(Course course) throws CourseNotFoundException ;
	 public Course findBySubject(String subject) throws CourseNotFoundException;
	 public List<Course> showAllCourses() throws CourseNotFoundException;
}
