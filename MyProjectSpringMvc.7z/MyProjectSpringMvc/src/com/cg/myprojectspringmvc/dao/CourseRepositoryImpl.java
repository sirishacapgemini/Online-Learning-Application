package com.cg.myprojectspringmvc.dao;

import java.util.ArrayList;
import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.myprojectspringmvc.dto.Course;
import com.cg.myprojectspringmvc.dto.Student;
import com.cg.myprojectspringmvc.exception.CourseNotFoundException;
import com.cg.myprojectspringmvc.query.QueryInterface;

@Repository
public class CourseRepositoryImpl implements CourseRepository{
	@PersistenceContext
	EntityManager em;
	   
	   /**@author siontedd:Written by Sirisha on 15-04-2019
	   Last modified on 22-05-2019
	   The Method save() is used to save course,student and address into the database
	 * @throws CourseNotFoundException */
	public Course save(Course course) throws CourseNotFoundException {
		System.out.println("In daoo......");
		System.out.println(course);
		List<Student> stuOne=new ArrayList<>();
		stuOne=course.getStudents();
		if(stuOne==null){
			em.persist(course);
			em.flush();
		}else {
			Student stu=new Student();
			stu.setEmailAddress(course.getStudents().get(0).getEmailAddress());
			stu.setName(course.getStudents().get(0).getName());
			stu.setPhoneNumber(course.getStudents().get(0).getPhoneNumber());
			stu.setAddress(course.getStudents().get(0).getAddress());
			
			stu.setCourse(course);
			em.persist(stu);
			em.flush();
		}
		
		return course;
		
		
		
		}
	
	
	/**Written by Sirisha on 15-04-2019
	   Last modified on 03-05-2019
	   The Method findBySubject() is used to find the particular subject from the database*/
	public Course findBySubject(String subject) throws CourseNotFoundException {
		return null;
		// TODO Auto-generated method stub
		
		/*try {
			//em=DBUtil.getConnection();
		Query query = em.createQuery(QueryInterface.sql);
		query.setParameter("subject", subject);
		Course course=(Course) query.getSingleResult();
		System.out.println(course);
		//course.getStudents().size();
		return course;
		}catch(Exception e) {
			throw new CourseNotFoundException("course not found");
			//e.printStackTrace();
		}
		finally {
			if(em!=null) {
				//em.close();
			}
		}
		*/
	}

	/**@author siontedd:Written by Sirisha on 15-04-2019
	   Last modified on 22-05-2019
	   The Method showAllCourses() is used to show all the courses from the database
	   @return list of courses
	 * @throws CourseNotFoundException */
	public List<Course> showAllCourses() throws CourseNotFoundException {
		// TODO Auto-generated method stub
		
		//em=DBUtil.getConnection();
		TypedQuery<Course> query = em.createQuery(QueryInterface.qStr, Course.class);
		List<Course> courseList = query.getResultList();
		return courseList;
		
		
	}


	public Course getCourse(Integer cId) {
		Course cour=null;
		try {
		Query query=em.createQuery("From Course where id=:cId");
		query.setParameter("cId", cId);
		cour=(Course) query.getSingleResult();
		
	}catch(NoResultException e) {
		System.out.println("no id found");
	}
		return cour;
	}
	

}
