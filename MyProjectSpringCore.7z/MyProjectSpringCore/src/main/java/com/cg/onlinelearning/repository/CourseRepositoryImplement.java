package com.cg.onlinelearning.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.onlinelearning.dto.Course;

import com.cg.onlinelearning.exception.CourseNotFoundException;
import com.cg.onlinelearning.util.DBUtil;
@Repository("repository")
/**Written by Sirisha on 15-04-2019
Last modified on 14-05-2019
The Method save() is used to save the course,student and address into the list*/
public class CourseRepositoryImplement implements CourseRepository{
	public Course save(Course course) throws CourseNotFoundException {
		for (Course courseOne:DBUtil.courseList) {
			if(courseOne.getId()==course.getId())
				return null;
		}	
		
			DBUtil.courseList.add(course);
			return course;
		
	}
	/**Written by Sirisha on 15-04-2019
	   Last modified on 14-05-2019
	   The Method showAllCourses() is used to show all the courses which are their in the list*/
    public List<Course> showAllCourses() {
// TODO Auto-generated method stub
		return DBUtil.courseList;
		}
    /**Written by Sirisha on 15-04-2019
	   Last modified on 14-05-2019
	   The Method findBySubject() is used to find a particular subject which is searched by the student*/
public Course findBySubject(String subject) throws CourseNotFoundException{
		for(Course course:DBUtil.courseList) {
			if(course.getSubject().equals(subject)){
				return course;
				}
			}
		return null;
}}
