package com.cg.onlinelearning.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
/**Written by Sirisha on 15-04-2019
Last modified on 14-05-2019
The class JavaConfig is used to configure all the classes which are there in that particular package*/
@Configuration
@ComponentScan({"com.cg.onlinelearning"})
public class JavaConfig {

}
