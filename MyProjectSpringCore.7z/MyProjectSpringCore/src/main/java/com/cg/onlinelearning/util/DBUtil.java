package com.cg.onlinelearning.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.onlinelearning.dto.Course;


public class DBUtil {
public static List<Course> courseList=new ArrayList<Course>();

}