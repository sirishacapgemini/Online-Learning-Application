package com.cg.onlinelearning.service;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.onlinelearning.dto.Course;
import com.cg.onlinelearning.dto.Student;
import com.cg.onlinelearning.exception.CourseNotFoundException;
import com.cg.onlinelearning.repository.CourseRepository;

@Service("service")
public class CourseServiceImplement implements CourseService{
	@Autowired
	private CourseRepository repository;
	/**Written by Sirisha on 15-04-2019
	   Last modified on 14-05-2019
	   The Method registerForCourse() is used to register for a particular course by the student*/
	public Course registerForCourse(String subject, Student student) throws CourseNotFoundException{
		// TODO Auto-generated method stub
		Course course=repository.findBySubject(subject);
		if(course!=null) {
			List<Student> studentList=new ArrayList<Student>();
			//cou.getStudents().add(student);
			if(course.getStudents()==null)
				studentList.add(student);
			else {
				studentList=course.getStudents();
				studentList.add(student);
			}
			course.setStudents(studentList);
			return course;
		}
		throw new CourseNotFoundException("course not found");

	}
	/**Written by Sirisha on 15-04-2019
	   Last modified on 14-05-2019
	   The Method add() is used to add a particular course into the list*/
public Course add(Course course) throws CourseNotFoundException {
		// TODO Auto-generated method stub
        Course courseOne=repository.save(course);
		if(courseOne==null)
			throw new CourseNotFoundException("Course already exists");
		return courseOne;
	
}
/**Written by Sirisha on 15-04-2019
Last modified on 14-05-2019
The Method searchBySubject() is used to search a course name from the list*/
public List<Student> searchBySubject(String subject) throws CourseNotFoundException{
	Course course=repository.findBySubject(subject);
	if(course==null)
		throw new CourseNotFoundException("Course not found");
	    	return course.getStudents();
}
/**Written by Sirisha on 15-04-2019
Last modified on 14-05-2019
The Method showAllCourses() is used to show all courses which are their in the list*/
	public List<Course> showAllCourses() {
		// TODO Auto-generated method stub
		return repository.showAllCourses();}
	}
