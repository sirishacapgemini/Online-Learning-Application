package com.cg.onlinelearning.ui;
import java.math.BigInteger;
import java.util.*;
import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.onlinelearning.dto.Address;
import com.cg.onlinelearning.dto.Course;
import com.cg.onlinelearning.dto.Student;
import com.cg.onlinelearning.exception.CourseNotFoundException;
import com.cg.onlinelearning.service.CourseService;

import com.cg.onlinelearning.config.JavaConfig;
@Component
public class Application {
	@Autowired
	CourseService serviceCourse;
	
	static CourseService service;
	@PostConstruct
	public void init() {
		service=this.serviceCourse;
	}
    public static void main( String[] args ){
    	AnnotationConfigApplicationContext app=new AnnotationConfigApplicationContext(JavaConfig.class);
      Scanner sc=new Scanner(System.in);
      int choice=0;
   do{
   	printDetails();
   	System.out.println("enter the choice");
   	choice=sc.nextInt();
   	switch(choice) {
   	case 1://adding course
   		System.out.println("enter the course id");
   		int id=sc.nextInt();
   		System.out.println("enter course name");
   		String name=sc.next();
   		Course course=(Course) app.getBean("course");
   		course.setId(id);
   		course.setSubject(name);
   		
   		try {
			service.add(course);
		} catch (CourseNotFoundException e3) {
			// TODO Auto-generated catch block
			//e3.printStackTrace();
			System.err.println(e3.getMessage());
			break;
		}
   		System.err.println("******Course added successfully********");
   		break;
   	case 2://showing all courses which are their in the list
   		List<Course> myList=service.showAllCourses();
   		System.err.println("********Course Details**********");
   		//System.out.println(course);
		for(Course courseData:myList) {
			
			System.out.println("CourseId is "+courseData.getId());
			System.out.println("CourseName is "+courseData.getSubject());
		}break;
   	case 3://student registering for course
   		Student studentOne=(Student) app.getBean("student");
    	Address addressOne=(Address) app.getBean("address");
   		System.out.println("enter the course subject");
   		String courseName=sc.next();
   		try {
			service.searchBySubject(courseName);
		} catch (CourseNotFoundException e2) {
			// TODO Auto-generated catch block
			System.err.println(e2.getMessage());
			break;}
   		System.out.println("enter student name");
   		String snameOne=sc.next();
   		System.out.println("enter the phone number");
   		BigInteger phnNo=sc.nextBigInteger();
   		System.out.println("enter the mailId");
   		String emailId=sc.next();
   		System.out.println("enter the state");
   		String state=sc.next();
   		System.out.println("enter the city");
   		String city=sc.next();
   		System.out.println("enter the pincode");
   		int pinCode=sc.nextInt();
   		studentOne.setName(snameOne);
   		studentOne.setEmailAddress(emailId);
   		studentOne.setPhoneNumber(phnNo);
   		
   		addressOne.setCity(city);
   		addressOne.setState(state);
   		addressOne.setPinCode(pinCode);
   		studentOne.setAddress(addressOne);
   		
   		
   	try {
   		service.registerForCourse(courseName, studentOne);
		} catch (CourseNotFoundException e1) {
			// TODO Auto-generated catch block
			System.out.println(e1.getMessage());
		}
   	System.err.println("*********Registered successfully**********");
   	System.out.println("Name is "+studentOne.getName());
   	System.out.println("Email is "+studentOne.getEmailAddress());
   	System.out.println("Mobile No is "+studentOne.getPhoneNumber());
   	System.out.println("City is "+studentOne.getAddress().getCity());
   	System.out.println("State is "+studentOne.getAddress().getState());
   	System.out.println("Pincode is "+studentOne.getAddress().getPinCode());
		   break;
   	case 4://search a particular course and showing list of students for that course
   		System.out.println("enter the course subject to search");
   		String sname=sc.next();
   		List<Student> studentSearch=null;
		try {
			studentSearch = service.searchBySubject(sname);
			
			for (Student student : studentSearch) {
				System.err.println("******List of students********");
				System.out.println("Student name is "+ student.getName());
				System.out.println("Phone number is "+student.getPhoneNumber());
				System.out.println("Email address is "+student.getEmailAddress());
				System.out.println("Address is "+student.getAddress());
			}
			} catch(CourseNotFoundException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());}
   		break;
   		default:System.err.println("Incorrect choice");
   		break;}}while(choice!=5);}
    static void printDetails() {
	System.out.println("1.Add course");
	System.out.println("2.show all courses");
	System.out.println("3.Register for course");
	System.out.println("4.search by course subject name");}}