package com.cg.onlinelearning.dto;
import java.util.List;


import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
@Component("course")
@Scope("prototype")
public class Course {
private int id;
private String subject;
private List<Student> students;
public Course() {
}
public Course(int id, String subject, List<Student> students) {
	super();
	this.id = id;
	this.subject = subject;
	this.students = students;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getSubject() {
	return subject;
}
public void setSubject(String subject) {
	this.subject = subject;
}
public List<Student> getStudents() {
	return students;
}
public void setStudents(List<Student> students) {
	this.students = students;
}
@Override
public String toString() {
	return "Course [id=" + id + ", subject=" + subject + ", students=" + students + "]";
}

}