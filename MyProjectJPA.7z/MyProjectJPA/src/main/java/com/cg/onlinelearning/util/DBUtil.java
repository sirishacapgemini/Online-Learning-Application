package com.cg.onlinelearning.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.onlinelearning.dto.Course;
import com.cg.onlinelearning.dto.Student;
import com.cg.onlinelearning.exception.CourseNotFoundException;

public class DBUtil {
	static EntityManager em=null;
	public static EntityManager getConnection() {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("onlinelearningmanagement");
    em=emf.createEntityManager();
    em.getTransaction().begin();
    return em;

	}
}