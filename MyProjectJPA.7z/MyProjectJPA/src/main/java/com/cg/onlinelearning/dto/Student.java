package com.cg.onlinelearning.dto;

import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="student_table")
public class Student {
@Column(name="student_name")
private String name;
@Column(name="student_number")
private BigInteger phoneNumber;
@Id
@Column(name="student_email")
private String emailAddress;
@OneToOne(cascade=CascadeType.ALL)
private Address address;
/*@ManyToOne
@JoinColumn(name="course_No")
private Course course;*/

public Student(){
}



public Student(String name, BigInteger phoneNumber, String emailAddress, Address address) {
	super();
	this.name = name;
	this.phoneNumber = phoneNumber;
	this.emailAddress = emailAddress;
	this.address = address;
	//this.course = course;
}



public String getName() {
	return name;}
public void setName(String name) {
	this.name = name;}
public BigInteger getPhoneNumber() {
	return phoneNumber;}
public void setPhoneNumber(BigInteger phoneNumber) {
	this.phoneNumber = phoneNumber;}
public String getEmailAddress() {
	return emailAddress;}
public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;}
public Address getAddress() {
	return address;}
public void setAddress(Address address) {
	this.address = address;}

/*public Course getCourse() {
	return course;
}
public void setCourse(Course course) {
	this.course = course;
}*/


@Override
public String toString() {
	return "Student [name=" + name + ", phoneNumber=" + phoneNumber + ", emailAddress=" + emailAddress + ", address="
			+ address + "]";
}



}
