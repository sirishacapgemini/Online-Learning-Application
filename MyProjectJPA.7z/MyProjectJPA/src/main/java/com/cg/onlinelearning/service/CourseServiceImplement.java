package com.cg.onlinelearning.service;
import java.sql.SQLException;
import java.util.*;
import com.cg.onlinelearning.repository.*;
import com.cg.onlinelearning.dto.Course;
import com.cg.onlinelearning.dto.Student;
import com.cg.onlinelearning.exception.CourseNotFoundException;
import com.cg.onlinelearning.repository.CourseRepository;
import com.cg.onlinelearning.util.DBUtil;
public class CourseServiceImplement implements CourseService{
	private CourseRepository repository;
	public CourseServiceImplement() {
		repository=new CourseRepositoryImplement();}
	/**Written by Sirisha on 15-04-2019
	 Last modified on 03-05-2019
	 The Method registerForCourse() is used to add new student to the particular mentioned subject*/
	public Course registerForCourse(String subject, Student student) throws CourseNotFoundException, SQLException{
		// TODO Auto-generated method stub
		Course course=repository.findBySubject(subject);
		if(course!=null) {
			List<Student> studentsList=new ArrayList<Student>();
			if(course.getStudents()!=null)
				studentsList=course.getStudents();
			studentsList.add(student);
			course.setStudents(studentsList);
			return repository.save(course);
		}
		throw new CourseNotFoundException("course not found");

	}
	/**Written by Sirisha on 15-04-2019
	 Last modified on 03-05-2019
	 The Method add() is used to add new course into the database*/
public Course add(Course course) throws CourseNotFoundException, SQLException {
		// TODO Auto-generated method stub
		repository.save(course);
		return course;
		}
/**Written by Sirisha on 15-04-2019
Last modified on 03-05-2019
The Method searchBySubject() is used to search a particular subject and returns the list of students who got registered for that course*/
public List<Student> searchBySubject(String subject) throws CourseNotFoundException{
	Course course=repository.findBySubject(subject);
	if(course==null)
		throw new CourseNotFoundException("course not found");
	    	return course.getStudents();
}
/**Written by Sirisha on 15-04-2019
Last modified on 03-05-2019
The Method showAllCourses() is used to retrieve all the courses which are there in the database*/
	public List<Course> showAllCourses() throws CourseNotFoundException {
		// TODO Auto-generated method stub
		return repository.showAllCourses();}
	}
