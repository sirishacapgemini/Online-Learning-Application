package com.cg.onlinelearning.query;

public interface QueryInterface {
	String sql="from Course where subject =:subject";
	String qStr = "SELECT course FROM Course course ";
}
