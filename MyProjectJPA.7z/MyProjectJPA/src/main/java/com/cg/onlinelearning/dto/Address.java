package com.cg.onlinelearning.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="address_table")
public class Address {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name="address_id")
private int addid;
@Column(name="address_city")
private String city;
@Column(name="address_state")
private String state;
@Column(name="address_pincode")
private int pinCode;
public Address() {
}
public Address(String city, String state, int pinCode) {
	super();
	this.city = city;
	this.state = state;
	this.pinCode = pinCode;}
public String getCity() {
	return city;}
public void setCity(String city) {
	this.city = city;}
public String getState() {
	return state;}
public void setState(String state) {
	this.state = state;}
public int getPinCode() {
	return pinCode;}
public void setPinCode(int pinCode) {
	this.pinCode = pinCode;}
@Override
public String toString() {
	return "Address [city=" + city + ", state=" + state + ", pinCode=" + pinCode + "]";
}}
