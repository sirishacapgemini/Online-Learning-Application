package com.cg.onlinelearning.repository;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.onlinelearning.dto.Address;
import com.cg.onlinelearning.dto.Course;
import com.cg.onlinelearning.dto.Student;
import com.cg.onlinelearning.exception.CourseNotFoundException;
import com.cg.onlinelearning.query.QueryInterface;
import com.cg.onlinelearning.util.DBUtil;
public class CourseRepositoryImplement implements CourseRepository{
	EntityManager em;
	   public CourseRepositoryImplement() {
		   //em=DBUtil.getConnection();
	   }
	   /**Written by Sirisha on 15-04-2019
	   Last modified on 03-05-2019
	   The Method save() is used to save course,student and address into the database
	 * @throws CourseNotFoundException */
	public Course save(Course course) throws CourseNotFoundException {
		// TODO Auto-generated method stub
		try {
		em=DBUtil.getConnection();
		em.merge(course);
	    em.getTransaction().commit();
		return course;
		}
		catch(Exception e) {
		throw new CourseNotFoundException("data not found");
			
		}
		finally {
			if(em!=null) 
				em.close();
			}
		
		}
	
	
	/**Written by Sirisha on 15-04-2019
	   Last modified on 03-05-2019
	   The Method findBySubject() is used to find the particular subject from the database*/
	public Course findBySubject(String subject) throws CourseNotFoundException {
		// TODO Auto-generated method stub
		
		try {
			em=DBUtil.getConnection();
		TypedQuery<Course> query = em.createQuery(QueryInterface.sql,Course.class);
		query.setParameter("subject", subject);
		Course course=query.getSingleResult();
		return course;
		}catch(Exception e) {
			throw new CourseNotFoundException("course not found");
		}
		finally {
			if(em!=null) {
				em.close();
			}
		}
		
	}

	/**Written by Sirisha on 15-04-2019
	   Last modified on 03-05-2019
	   The Method showAllCourses() is used to show all the courses from the database
	 * @throws CourseNotFoundException */
	public List<Course> showAllCourses() throws CourseNotFoundException {
		// TODO Auto-generated method stub
		try {
		em=DBUtil.getConnection();
		TypedQuery<Course> query = em.createQuery(QueryInterface.qStr, Course.class);
		List<Course> courseList = query.getResultList();
		return courseList;
		}catch(Exception e) {
			throw new CourseNotFoundException("course not found");
		}

		finally {
			if(em!=null) {
				em.close();
			}
		}
	}
	
	

}
	