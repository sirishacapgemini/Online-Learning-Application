package com.cg.myprojectspringdata.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.myprojectspringdata.controller.MyController;
import com.cg.myprojectspringdata.dao.CourseDao;
import com.cg.myprojectspringdata.dto.Course;
import com.cg.myprojectspringdata.dto.Student;
import com.cg.myprojectspringdata.exception.CourseNotFoundException;
/**@author siontedd:Written by Sirisha on 15-04-2019
*Last modified on 25-05-2019
*The class CourseServiceImpl is a implemention class for the service interface**/

@Service
public class CourseServiceImpl implements CourseService{
	@Autowired
    CourseDao dao;
/**@author siontedd:Written by Sirisha on 15-04-2019
*Last modified on 25-05-2019
*The method registerForCourse is used to register for a particular course
*@return is course object
*@param String subject,and a student object
*@throws CourseNotFoundException exception**/
	@Override
	public Course registerForCourse(String subject, Student students) throws CourseNotFoundException {
		// TODO Auto-generated method stub
		if(MyController.logger.isDebugEnabled()){
			MyController.logger.debug("addCourseService registerForCourse(String subject, Student students) is executed!");
			
		}
		Course course=dao.findBySubject(subject);
		if(course!=null) {
			List<Student> studentsList=new ArrayList<Student>();
			if(course.getStudents()!=null)
				studentsList=course.getStudents();
			studentsList.add(students);
			course.setStudents(studentsList);
			return dao.save(course);
		}
		throw new CourseNotFoundException("course not found");
	}
	/**@author siontedd:Written by Sirisha on 15-04-2019
	*Last modified on 25-05-2019
	*The method add is used to add a particular course
	*@return is course object
	*@param Course course object
	*@throws CourseNotFoundException exception**/

	@Override
	public Course add(Course course) throws CourseNotFoundException {
		// TODO Auto-generated method stub
		if(MyController.logger.isDebugEnabled()){
			MyController.logger.debug("addCourseService add(Course course) is executed!");
			
		}
		 Course courseOne=dao.findBySubject(course.getSubject());
		if(courseOne==null)
		return dao.save(course);
		     throw new CourseNotFoundException("course not found");
	}
	/**@author siontedd:Written by Sirisha on 15-04-2019
	*Last modified on 25-05-2019
	*The method searchBySubject is used to search a course and show the list of students
	*@return is List<Student>
	*@param String subject
	*@throws CourseNotFoundException exception**/

	@Override
	public List<Student> searchBySubject(String subject) throws CourseNotFoundException {
		// TODO Auto-generated method stub
		if(MyController.logger.isDebugEnabled()){
			MyController.logger.debug("addCourseService searchBySubject(String subject) is executed!");
			
		}
		Course course=dao.findBySubject(subject);
		if(course==null) {
			MyController.logger.error(new CourseNotFoundException());
			throw new CourseNotFoundException("course not found");
			
		}
		    	return course.getStudents();
	}
	/**@author siontedd:Written by Sirisha on 15-04-2019
	*Last modified on 25-05-2019
	*The method showAllCourses() is used to show list of courses which are their in the database
	*@return is List<Course>
	**/

	@Override
	public List<Course> showAllCourses() {
		if(MyController.logger.isDebugEnabled()){
			MyController.logger.debug("addCourseService searchBySubject(String subject) is executed!");
			
		}
		// TODO Auto-generated method stub
		return dao.findAll();
	}

}
