package com.cg.myprojectspringdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
/**@author siontedd:Written by Sirisha on 15-04-2019
*Last modified on 25-05-2019
*The class MyProjectSpringDataApplication is used to declare a main method in which we will 
*call a static method called run .
*@SpringBootApplication is a common annotation that wraps up the 3 annotations i.e.,@Configuration,
*@ComponentScan,@AutoEnableConfiguration**/
@SpringBootApplication
//@ComponentScan("com.cg.myprojectspringdata")
public class MyProjectSpringDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyProjectSpringDataApplication.class, args);
		System.out.println("heyyyyyyyyyyyy............");
	}

}
