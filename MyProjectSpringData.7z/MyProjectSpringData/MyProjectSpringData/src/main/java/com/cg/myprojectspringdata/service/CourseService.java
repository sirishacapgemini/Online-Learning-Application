package com.cg.myprojectspringdata.service;


import java.util.List;

import com.cg.myprojectspringdata.dto.Course;
import com.cg.myprojectspringdata.dto.Student;
import com.cg.myprojectspringdata.exception.CourseNotFoundException;
/**@author siontedd:Written by Sirisha on 15-04-2019
*Last modified on 25-05-2019
*The interface CourseService is used to declare the methods which are used to fulfill the business 
*logic requirements**/

public interface CourseService {
	public Course registerForCourse(String subject,Student students) throws CourseNotFoundException;
	public Course add(Course course) throws CourseNotFoundException;
	public List<Student> searchBySubject(String subject) throws CourseNotFoundException;
	public List<Course> showAllCourses();
}
