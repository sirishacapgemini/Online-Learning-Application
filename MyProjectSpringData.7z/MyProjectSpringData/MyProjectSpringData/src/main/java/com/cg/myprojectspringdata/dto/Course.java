package com.cg.myprojectspringdata.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
/**@author siontedd:Written by Sirisha on 15-04-2019
*Last modified on 25-05-2019
*The class Course is a dto class which have getters ,setters,constructs and  toString method**/
@Entity
@Table(name="course_table")
public class Course {
@Id
private int id;
@Column(unique=true)
private String subject;
@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
@JoinColumn(name="course_No")
private List<Student> students;
public Course() {
	
}
public Course(int id, String subject) {
	super();
	this.id = id;
	this.subject = subject;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getSubject() {
	return subject;
}
public void setSubject(String subject) {
	this.subject = subject;
}

public List<Student> getStudents() {
	return students;
}
public void setStudents(List<Student> students) {
	this.students = students;
}
@Override
public String toString() {
	return "Course [id=" + id + ", subject=" + subject + ", students=" + students + "]";
}


}
