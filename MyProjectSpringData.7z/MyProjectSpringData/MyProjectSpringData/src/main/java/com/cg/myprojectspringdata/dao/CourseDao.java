package com.cg.myprojectspringdata.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.myprojectspringdata.dto.Course;
/**@author siontedd:Written by Sirisha on 15-04-2019
*Last modified on 25-05-2019
*The interface CourseDao extends JpaRepository which have inbuilt save and findAll methods and also
*we dont a dao implementation class**/
public interface CourseDao extends JpaRepository<Course,Integer>{
public Course findBySubject(String name);
}
