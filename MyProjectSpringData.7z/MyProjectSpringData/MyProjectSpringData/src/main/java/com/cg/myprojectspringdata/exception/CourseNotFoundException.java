package com.cg.myprojectspringdata.exception;
/**@author siontedd:Written by Sirisha on 15-04-2019
*Last modified on 25-05-2019
*The class CourseNotFoundException is exception class which extends Exception class**/
public class CourseNotFoundException extends Exception{
public CourseNotFoundException() {
	super();
}
public CourseNotFoundException(String s) {
	super(s);
}
}
