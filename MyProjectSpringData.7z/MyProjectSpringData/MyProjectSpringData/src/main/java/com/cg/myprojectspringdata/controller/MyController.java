package com.cg.myprojectspringdata.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.myprojectspringdata.dto.Course;
import com.cg.myprojectspringdata.dto.Student;
import com.cg.myprojectspringdata.exception.CourseNotFoundException;
import com.cg.myprojectspringdata.service.CourseService;
import org.apache.log4j.Logger; 
/**@author siontedd:Written by Sirisha on 15-04-2019
*Last modified on 25-05-2019
*The class MyController is used to control the whole spring boot application by giving the 
*@RequestMapping to map the particular given mapping**/
@RestController
@RequestMapping("/mycontroller")
@CrossOrigin(origins="http://localhost:4200")
public class MyController {
	
	public static final Logger logger = Logger.getLogger(MyController.class);
	@Autowired
   CourseService service;
	/**@author siontedd:Written by Sirisha on 15-04-2019
	*Last modified on 25-05-2019
	*The method addCourse is used to add a new course into the database
	*@return is  ResponseEntity<Course>
	*@param @ModelAttribute Course course
	*@throws CourseNotFoundException exception
	*@RequestMapping to map the particular given mapping**/
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public ResponseEntity<Course> addCourse(@ModelAttribute Course course) {
		Course courseOne;
		try {
			courseOne = service.add(course);
		} catch (CourseNotFoundException e) {
			// TODO Auto-generated catch block
			return new ResponseEntity("Course already exists",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Course>(courseOne,HttpStatus.OK);
		
	}
	/**@author siontedd:Written by Sirisha on 15-04-2019
	*Last modified on 25-05-2019
	*The method showCourse is used to show list of courses and the students also who got registered 
	*for that particular course
	*@return is  ResponseEntity<List<Course>>
	*@param @ModelAttribute Course course
	*@throws CourseNotFoundException exception
	*@RequestMapping to map the particular given mapping**/
	@RequestMapping(value="/show",method=RequestMethod.GET)
	public ResponseEntity<List<Course>> showCourse() {
		List<Course> courseList=service.showAllCourses();
		if(courseList==null) {
			return new ResponseEntity("No courses to show",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Course>>(courseList,HttpStatus.OK);
		
	}
	/**@author siontedd:Written by Sirisha on 15-04-2019
	*Last modified on 25-05-2019
	*The method registerCourse is used to register for a particular course 
	*@return is  ResponseEntity<Course>
	*@param @ModelAttribute Student student,@RequestParam to request the parameter
	*@throws CourseNotFoundException exception
	*@RequestMapping to map the particular given mapping**/
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public ResponseEntity<Course> registerCourse(@RequestParam("subject") String name,@ModelAttribute Student student) {
		
		Course courseOne;
		try {
			courseOne = service.registerForCourse(name, student);
			//System.out.println(courseOne);
		} catch (CourseNotFoundException e) {
			// TODO Auto-generated catch block
			return new ResponseEntity(name+" course is not there to register",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Course>(courseOne,HttpStatus.OK);
	}
	/**@author siontedd:Written by Sirisha on 15-04-2019
	*Last modified on 25-05-2019
	*The method searchCourse is used to search a course and returns the students who got registered
	*@return is  ResponseEntity<List<Student>>
	*@param @RequestParam is used to request parameter ie. subject name
	*@throws CourseNotFoundException exception
	*@RequestMapping to map the particular given mapping**/
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public ResponseEntity<List<Student>> searchCourse(@RequestParam("subject") String name) {
		List<Student> studentList = null;
		try {
			studentList = service.searchBySubject(name);
		} catch (CourseNotFoundException e) {
			// TODO Auto-generated catch block
			return new ResponseEntity("Course not found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Student>>(studentList,HttpStatus.OK);
		
	}
}
